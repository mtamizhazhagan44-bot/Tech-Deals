---
name: FlashDrop
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3d4a42'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6d7a72'
  outline-variant: '#bccac0'
  surface-tint: '#006c4a'
  primary: '#006948'
  on-primary: '#ffffff'
  primary-container: '#00855d'
  on-primary-container: '#f5fff7'
  inverse-primary: '#68dba9'
  secondary: '#a73a00'
  on-secondary: '#ffffff'
  secondary-container: '#fd651e'
  on-secondary-container: '#571a00'
  tertiary: '#825100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#85f8c4'
  primary-fixed-dim: '#68dba9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#005137'
  secondary-fixed: '#ffdbce'
  secondary-fixed-dim: '#ffb599'
  on-secondary-fixed: '#370e00'
  on-secondary-fixed-variant: '#7f2b00'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-numeric-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '800'
    lineHeight: 24px
    letterSpacing: -0.01em
  label-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '800'
    lineHeight: 12px
    letterSpacing: 0.04em
  label-ticker:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system powers a high-velocity, impulse-driven affiliate shopping application built around limited-time drops, flash savings, and curated product discovery. The aesthetic balances high-octane urgency with unwavering retail credibility: vibrant callouts trigger instantaneous engagement without veering into abrasive discount noise.

The style fuses modern e-commerce minimalism with tactile urgency accents:
- **Kinetic Precision:** Crisp layout structures, micro-interactions, and tight numerical treatments make flash counters and percent-off metrics immediately graspable.
- **Trustworthy Polish:** Generous internal card spacing, refined hairline strokes, and balanced neutral foundations prevent visual fatigue, distinguishing the experience from spam-heavy coupon aggregators.
- **Dynamic Energy:** Punchy action colors guide users directly down the conversion funnel toward immediate checkout triggers.

## Colors

The palette is engineered for instantaneous visual triage:

- **Primary (`#059669` - Electric Emerald):** Anchors core actions, verified savings validations, primary checkout buttons, and successful deal redemption states. Delivers confidence, prosperity, and affirmative feedback.
- **Secondary (`#EA580C` - Blaze Coral):** The driver of scarcity. Deployed on expiring flash deal tags, live drop pulses, high-percentage discount badges, and immediate action alerts.
- **Tertiary (`#F59E0B` - Amber Flare):** Reserved for countdown tickers, running-low stock thresholds, and community buzz indicators.
- **Neutral (`#0F172A` - Slate Obsidian):** Deep slate foundation for typography and structural anchors, ensuring high-contrast readability across screen environments while avoiding harsh pitch black. Surface tiers utilize subtle slate-tinted washes (`#F8FAFC` base background, `#FFFFFF` cards).

## Typography

Typography prioritizes rapid scannability, legibility across varying device sizes, and high-impact price hierarchies. **Plus Jakarta Sans** provides a geometric, forward-leaning architecture with open counters and robust weights, lending both structural clarity to commercial listings and expressive punch to flash deals.

- **Numerics & Discounts:** All price points, discount percentages, and countdown sequences must utilize `font-variant-numeric: tabular-nums` to eliminate jitter during active timer micro-ticks.
- **Price Hierarchy:** Slashed MSRP prices render in `body-sm` muted slate, placed alongside the active promotional price in `label-numeric-lg` or `headline-md` for maximum perceived value delta.
- **Badges & Tags:** Discount tags enforce uppercase treatment (`label-badge`) with positive letter-spacing to optimize legibility on high-saturation badges.

## Layout & Spacing

The layout philosophy follows a mobile-first, modular fluid approach built around a compact vertical cadence:

- **Grid Architecture:** 
  - **Mobile (<640px):** 4-column system with a `1rem` (16px) margin and `0.75rem` (12px) gutter. Deal feeds default to 2-column card layouts or single-column hero feeds.
  - **Tablet (640px–1024px):** 8-column layout, `1.5rem` outer margins, `1rem` gutters.
  - **Desktop/Large Tablet (>1024px):** 12-column constrained grid (max-width: 1200px) with `1.5rem` gutters.
- **Vertical Rhythm:** Strict multiples of 4px. Element groups use `space-xs` (4px) and `space-sm` (8px), while distinct content modules within cards leverage `space-md` (16px).
- **Horizontal Carousels:** Category filters, ending-soon carousels, and merchant rows intentionally bleed past the screen edge using fractional card exposures to cue horizontal scrollability.

## Elevation & Depth

Visual hierarchy uses clean tonal layering paired with colored ambient shadows to lift interactive drop elements above the page plane:

- **Base Canvas:** Flat slate wash (`#F8FAFC`).
- **Surface Elevation 1 (Resting Deal Cards):** White solid fill with a low-opacity, dual ambient shadow (`0 2px 4px -1px rgba(15, 23, 42, 0.04), 0 4px 12px -2px rgba(15, 23, 42, 0.06)`) paired with a 1px border in slate outline (`rgba(15, 23, 42, 0.06)`).
- **Surface Elevation 2 (Active Drop / Elevated State):** Used for pinned deal alerts, bottom action sheets, and modal claims. Raised shadow: `0 12px 24px -4px rgba(15, 23, 42, 0.10), 0 4px 8px -2px rgba(15, 23, 42, 0.04)`.
- **Urgent Accents (Pulse Glow):** Live countdown timers and final-drop CTAs leverage soft, color-tinted backdrops: `0 4px 14px 0 rgba(234, 88, 12, 0.28)`.

## Shapes

The interface embraces a rounded, contemporary aesthetic that feels inviting and mobile-native:

- **Standard Containers & Cards:** Base radius of `0.5rem` (8px) ensures crisp image containment and clean card compartmentalization.
- **Hero Modules & Sheets:** Larger bottom sheets, modal drawers, and hero banners scale up to `rounded-lg` (`1rem` / 16px) or `rounded-xl` (`1.5rem` / 24px) to create smooth, tactile edges against viewports.
- **Interactive Micro-Surfaces (Pill Overrides):** Category chips, discount pills, timer tags, and floating action buttons utilize full capsule pill shapes (`9999px`) to emphasize distinct touch targets and quick-scan readability.

## Components

### Buttons
- **Primary Affiliate CTA ("Claim Drop" / "Get Deal"):** Full-width, high-contrast Electric Emerald (`#059669`) fill with white text (`Plus Jakarta Sans 700`), 48px standard touch target height, `0.5rem` radius. Includes a subtle, forward-pointing chevron icon on the right edge.
- **Urgent / Expiring CTA:** Blaze Coral (`#EA580C`) fill, deployed exclusively on deals expiring in under 15 minutes or inventory drops below 10%.
- **Secondary Outlined:** 1.5px border in Slate Obsidian (`rgba(15, 23, 42, 0.15)`), transparent fill, slate text.

### Discount Badges
- **Percentage Tags:** Pill-shaped, Blaze Coral solid background with stark white text, or an inverted tint variant (`rgba(234, 88, 12, 0.12)` fill with `#EA580C` text). Applied on top-left image corners with 8px internal offset.
- **Verified Deals Badge:** Electric Emerald tint (`rgba(5, 150, 105, 0.12)`) with a verified checkmark icon and 11px uppercase bold copy.

### Countdown Timers
- **Inline Ticker:** Monospaced tabular numeric styling encapsulated within an Amber Flare or Coral pill badge (`#0F172A` background with `#F59E0B` or `#EA580C` text and clock icon). 
- **Time Block Segment:** For mega drop banners, hours/minutes/seconds render in isolated high-contrast charcoal blocks (`#0F172A`) with white tabular digits.

### Product Deal Cards
- **Structure:** 1:1 square media viewport on top with auto-calculated aspect ratio, followed by a tight 12px content stack: store logo/name, 2-line truncated deal title, slashed original price, bold green deal price, and live scarcity progress bar.
- **Claim Progress Bar:** 4px high track (`rgba(15, 23, 42, 0.08)`) with an active fill gradient transitioning from Amber Flare to Blaze Coral representing stock claimed.

### Inputs & Filters
- **Deal Search Bar:** 44px height, light slate fill (`#F1F5F9`), zero default border, magnifying glass icon at left, and instant clear control at right. Focused state produces a 1.5px Electric Emerald border.
- **Filter Chips:** Capsule pills with `space-sm` vertical and `space-md` horizontal padding. Unselected: `#FFFFFF` fill with hairline outline. Selected: `#0F172A` dark background with crisp white typography.